Thank you for your interest in Amazon Appstore SDK.

We are continually improving our APIs and recently introduced Appstore SDK 3.0.9.
See https://developer.amazon.com/docs/appstore-sdk/appstore-sdk-overview.html

Previously, when you uploaded Android APKs into the Amazon Appstore,Â 
you had the option to select Yes or No for "Apply Amazon DRM?" on the APK Files tab.
If you selected Yes, the Appstore would wrap your APK with code allowing Amazon to enforce DRM for your app.

As of Appstore SDK 3.0.2, Amazon no longer adds this wrapper around your APK after you submit it.

Instead, if you need DRM for your Java Android app, you need to take some extra stepsÂ 
to incorporate some license checking functions in your app through the DRM APIÂ 
(availableÂ through the Appstore SDK).

For IAP functionality in your app using previous Appstore SDK releases,Â 
you had to download the standalone IAP JAR file and incorporate it into your app.Â 
The IAP API is no longer available as a separate JAR file;Â 
it is now bundled with the Appstore SDK JAR file.Â 
To implement IAP, you must incorporate the Appstore SDK.

To implement Simple Sign-in functionality in your app, you must incorporate the Appstore SDK.
To learn about Simple Sign-in, see https://developer.amazon.com/docs/ssi/understanding-ssi.html.

Thanks,
Amazon Appstore
