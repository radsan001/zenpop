package com.amazon.sample.iap.entitlement;

import java.util.Arrays;
import java.util.List;

/**
 *
 * MySku enum contains all In App Purchase products definition that the sample
 * app will use. The product definition includes two properties: "SKU" and
 * "Available Marketplace".
 *
 */
public enum MySku {


    // The only entitlement product used in this sample app
    // Sku + List of marketplaces where entitlement is available
    LEVEL2("com.amazon.sample.iap.entitlement.level2",
            Arrays.asList("AU", "BR", "CA", "CN", "DE", "ES", "FR", "GB", "IN", "IT",
            "JP", "MX", "US"));

    private final String sku;
    private final List<String> availableMarketplaces;

    /**
     * Returns the MySku object from the specified Sku and marketplace value.
     * @param sku sku in string format
     * @param marketplace marketplace
     * @return MySku object corresponding to the sku and marketplace if possible, null otherwise
     */
    public static MySku fromSku(final String sku, final String marketplace) {
        if (LEVEL2.getSku().equals(sku) &&
                (marketplace == null || LEVEL2.getAvailableMarketplaces().contains(marketplace.toUpperCase()))) {
            return LEVEL2;
        }
        return null;
    }

    /**
     * Returns the Sku string of the MySku object
     *
     * @return sku
     */
    public String getSku() {
        return this.sku;
    }

    /**
     * Returns the Available Marketplace of the MySku object
     * @return list of available marketplaces
     */
    public List<String> getAvailableMarketplaces() {
        return this.availableMarketplaces;
    }

    MySku(final String sku, final List<String> availableMarketplaces) {
        this.sku = sku;
        this.availableMarketplaces = availableMarketplaces;
    }

}
