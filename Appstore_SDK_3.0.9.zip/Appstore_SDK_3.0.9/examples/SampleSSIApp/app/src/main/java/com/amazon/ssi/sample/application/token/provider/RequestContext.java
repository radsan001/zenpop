package com.amazon.ssi.sample.application.token.provider;

import com.amazon.simplesignin.types.common.IRequestContext;

public class RequestContext implements IRequestContext {
}
