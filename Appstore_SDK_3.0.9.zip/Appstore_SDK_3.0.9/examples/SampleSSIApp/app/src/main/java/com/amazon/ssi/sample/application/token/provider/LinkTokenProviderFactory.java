package com.amazon.ssi.sample.application.token.provider;

import com.amazon.simplesignin.linktoken.LinkTokenV1Provider;
import com.amazon.simplesignin.types.exceptions.TokenException;

public class LinkTokenProviderFactory {
    private static LinkTokenV1Provider linkTokenV1Provider;


    public static LinkTokenV1Provider getLinkedTokenV1Provider() throws TokenException {
        if(linkTokenV1Provider == null) {
            LinkTokenCryptoKeyProvider linkTokenCryptoKeyProvider = new LinkTokenCryptoKeyProvider();
            AppStorePublicKeyProvider appStorePublicKeyProvider = new AppStorePublicKeyProvider();
            linkTokenV1Provider =
                    new LinkTokenV1Provider(linkTokenCryptoKeyProvider, appStorePublicKeyProvider);
        }
        return linkTokenV1Provider;
    }
}
