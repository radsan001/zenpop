package com.amazon.ssi.sample.application.constants;

public class JugglerConstants {
    public JugglerConstants() {

    }
    public final static String TAG = "JugglerDemoApp";
    public final static String idpName = "<Provide IDP Name Here>";
    public final static String appId =  "APPID";
    public final static String userName =  "partneremail@domain.com";
    public static final String SANDBOX_MODE = "SANDBOX";
}
