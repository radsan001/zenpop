package com.amazon.ssi.sample.application.token.provider;

import android.util.Log;

import com.amazon.simplesignin.appstore.AppStoreKeyId;
import com.amazon.simplesignin.appstore.IAppStorePublicKeyProvider;
import com.amazon.simplesignin.types.common.IRequestContext;
import com.amazon.simplesignin.types.common.SimpleSignInCryptoKey;
import com.amazon.simplesignin.types.exceptions.AppStorePublicKeyException;
import com.amazon.ssi.sample.application.constants.JugglerConstants;


import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.X509EncodedKeySpec;
import org.jose4j.base64url.internal.apache.commons.codec.binary.Base64;

public class AppStorePublicKeyProvider implements IAppStorePublicKeyProvider {
    /*TRUNCATED - Paste your app's public key (encoded as base64/x509 string) here. */
    public static String publicKeyHC =    "<Public Key Here>";

    public static String TAG = JugglerConstants.TAG;


    @Override
    public SimpleSignInCryptoKey<PublicKey> getPublicKey(IRequestContext iRequestContext) throws AppStorePublicKeyException {
        try {
            AppStoreKeyId appStoreKeyId = new AppStoreKeyId(JugglerConstants.appId, "1");
            SimpleSignInCryptoKey<PublicKey> appStorePublicKey =
                    new SimpleSignInCryptoKey<>(readPublicKey(), appStoreKeyId.serialize());
            Log.i(TAG,"getPublicKey.Appstore public key successfully retrieved");
            return appStorePublicKey;
        } catch (Exception ex) {
            Log.e(TAG, "getPublicKey: ", ex);
            return null;
        }
    }


    public RSAPublicKey readPublicKey() throws Exception {
        String key = publicKeyHC;
        String publicKeyPEM = key
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replaceAll(System.lineSeparator(), "")
                .replace("-----END PUBLIC KEY-----", "");
        byte[] encoded = Base64.decodeBase64(publicKeyPEM);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(encoded);
        Log.i(TAG,"readPublicKey.Appstore public key successfully retrieved");
        return (RSAPublicKey) keyFactory.generatePublic(keySpec);
    }
}
