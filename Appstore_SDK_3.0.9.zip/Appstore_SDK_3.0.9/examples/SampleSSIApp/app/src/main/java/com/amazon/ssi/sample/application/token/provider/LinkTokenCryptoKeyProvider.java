package com.amazon.ssi.sample.application.token.provider;

import com.amazon.simplesignin.appstore.AppStoreKeyId;
import com.amazon.simplesignin.linktoken.ILinkTokenCryptoKeyProvider;
import com.amazon.simplesignin.types.common.IRequestContext;
import com.amazon.simplesignin.types.common.SimpleSignInCryptoKey;
import com.amazon.simplesignin.types.exceptions.TokenException;
import com.amazon.ssi.sample.application.constants.JugglerConstants;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class LinkTokenCryptoKeyProvider implements ILinkTokenCryptoKeyProvider {
    SimpleSignInCryptoKey<SecretKey> cryptoKey;
    public LinkTokenCryptoKeyProvider() throws TokenException {
        try {
            KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(128, new SecureRandom());
            SecretKey secretKey = keyGenerator.generateKey();
            AppStoreKeyId appStoreKeyId = new AppStoreKeyId(JugglerConstants.appId, "1");
            cryptoKey = new SimpleSignInCryptoKey(secretKey, appStoreKeyId.serialize());
        } catch (NoSuchAlgorithmException e) {
            throw new TokenException(e);
        }
    }
    @Override
    public SimpleSignInCryptoKey<SecretKey> getEncryptionKey(IRequestContext iRequestContext)
            throws TokenException {
 /*
 Return the encryption key to use for a given application revision. Partners who own
 multiple applications with each application having multiple revisions, can use
 IRequestContext object to pass relevant context about the request origin and
 pick the appropriate key to use.
 */
        return cryptoKey;
    }
    @Override
    public SimpleSignInCryptoKey<SecretKey> getDecryptionKey(IRequestContext iRequestContext,
                                                             String s) throws TokenException {
 /*
 Return the decryption key to use for a given application revision. Partners who own
 multiple applications with each application having multiple revisions, can use
 IRequestContext object to pass relevant context about the request origin and
 pick the appropriate key to use.
 */
        return cryptoKey;
    }
}
