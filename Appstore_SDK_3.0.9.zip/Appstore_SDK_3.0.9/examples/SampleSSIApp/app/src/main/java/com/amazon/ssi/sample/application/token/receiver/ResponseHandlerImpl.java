package com.amazon.ssi.sample.application.token.receiver;

import static com.amazon.ssi.sample.application.constants.JugglerConstants.SANDBOX_MODE;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.amazon.device.simplesignin.ISimpleSignInResponseHandler;
import com.amazon.device.simplesignin.SimpleSignInService;
import com.amazon.device.simplesignin.model.Link;
import com.amazon.device.simplesignin.model.RequestStatus;
import com.amazon.device.simplesignin.model.response.GetUserAndLinksResponse;
import com.amazon.device.simplesignin.model.response.LinkUserAccountResponse;
import com.amazon.device.simplesignin.model.response.RecordMetricsEventResponse;
import com.amazon.device.simplesignin.model.response.ShowLoginSelectionResponse;
import com.amazon.simplesignin.linktoken.LinkTokenV1Provider;
import com.amazon.simplesignin.ssitoken.SSITokenV1Validator;
import com.amazon.simplesignin.types.common.IRequestContext;
import com.amazon.simplesignin.types.common.LinkTokenInfo;
import com.amazon.simplesignin.types.common.SSIToken;
import com.amazon.simplesignin.types.common.SSITokenInfo;
import com.amazon.simplesignin.types.common.SSITokenSchema;
import com.amazon.simplesignin.types.exceptions.TokenException;
import com.amazon.ssi.sample.application.constants.JugglerConstants;
import com.amazon.ssi.sample.application.token.provider.LinkTokenProviderFactory;
import com.amazon.ssi.sample.application.token.provider.RequestContext;

import java.util.HashMap;
import java.util.Map;

public class ResponseHandlerImpl implements ISimpleSignInResponseHandler {

    private static final String TAG = JugglerConstants.TAG;
    private Context context;
    public static String directedAmazonUserId;

    public void setAppContext(Context context) {
        this.context = context;
    }

    public void showToast(String toastMessage) {
        Toast.makeText(context, toastMessage, Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onGetUserAndLinksResponse(GetUserAndLinksResponse getUserAndLinksResponse) {
        Log.i(TAG,"onGetUserAndLinksResponse : "+ getUserAndLinksResponse);
        Log.i(TAG, "onGetUserAndLinksResponse.getAmazonUserId: " + getUserAndLinksResponse.getAmazonUserId());
        Log.i(TAG, "onGetUserAndLinksResponse.getRequestStatus: "  + getUserAndLinksResponse.getRequestStatus());
        Log.i(TAG, "onGetUserAndLinksResponse.getRequestId: " + getUserAndLinksResponse.getRequestId());
        //Setting the DirectedAmazonUserId to be further used for createLink calls
        directedAmazonUserId = getUserAndLinksResponse.getAmazonUserId();
        if(getUserAndLinksResponse.getRequestStatus().toString().equals(RequestStatus.SUCCESSFUL.toString())) {
        Map<String, String> map = new HashMap<>();
        int count = 0;
        for(Link link: getUserAndLinksResponse.getLinks()) {
            Log.i(TAG, "onGetUserAndLinksResponse.getIdentityProviderName: " + link.getIdentityProviderName());
            Log.i(TAG, "onGetUserAndLinksResponse.getPartnerUserId: " + link.getPartnerUserId());
            count = count+1;
            decodeLinkToken(map, count, link);
            Log.i(TAG, "onGetUserAndLinksResponse: Successfully complete");
        }
        SimpleSignInService.showLoginSelection(map);
        } else {
            showToast("Get User links api failed with status : " + getUserAndLinksResponse.getRequestStatus());
        }
    }

    private void decodeLinkToken(Map<String, String> map, int count, Link link) {
        // add logic to fetch username by linkId
        boolean isSandBoxMode = SimpleSignInService.getSDKMode().equals(SANDBOX_MODE);
        try {
            LinkTokenV1Provider linkTokenV1Provider = LinkTokenProviderFactory.getLinkedTokenV1Provider();
            SSITokenV1Validator ssiTokenV1Validator
                    = new SSITokenV1Validator(linkTokenV1Provider);
            IRequestContext requestContext = new IRequestContext() {

            };
            SSIToken ssiToken = new SSIToken(link.getSsiToken().getToken(), SSITokenSchema.SSI_1_0);
            /**
             * Get Link token
             */
            SSITokenInfo ssiTokenInfo;
            if(isSandBoxMode) {
                // For AppTester testing in Sandbox mode. As AppTester does not have access to the
                // application’s Appstore private key. So verify SSI token will fail.
                ssiTokenInfo = ssiTokenV1Validator.decodeToken(ssiToken, requestContext);
            } else {
                ssiTokenInfo = ssiTokenV1Validator.decodeAndVerifyToken(ssiToken, requestContext);
            }
            Log.i(TAG, "onGetUserAndLinksResponse: ssiTokenInfo.DirectedAmazonUserId:" + ssiTokenInfo.getLinkInfo().getDirectedAmazonUserId());
            Log.i(TAG, "onGetUserAndLinksResponse: ssiTokenInfo.LinkToken:" + ssiTokenInfo.getLinkInfo().getLinkToken().getToken());
            Log.i(TAG, "onGetUserAndLinksResponse: ssiTokenInfo.DirectedPartnerUserId:" + ssiTokenInfo.getLinkInfo().getDirectedPartnerUserId());
            Log.i(TAG, "onGetUserAndLinksResponse: ssiTokenInfo.IssuedAt:" + ssiTokenInfo.getTokenMetadata().getIssuedAt());
            /**
             * Validate link token
             */
            LinkTokenInfo linkTokenInfo = linkTokenV1Provider.validateLinkToken(ssiTokenInfo,requestContext);
            Log.i(TAG, "onGetUserAndLinksResponse: linkTokenInfo.DirectedAmazonUserId:" + linkTokenInfo.getDirectedAmazonUserId());
            Log.i(TAG, "onGetUserAndLinksResponse: linkTokenInfo.PartnerUserId:" + linkTokenInfo.getPartnerUserId());
            Log.i(TAG, "onGetUserAndLinksResponse: linkTokenInfo.LinkVerificationKey:" + linkTokenInfo.getLinkVerificationKey());
            Log.i(TAG, "onGetUserAndLinksResponse: linkTokenInfo.CustomFields:" + linkTokenInfo.getCustomFields());
            map.put("partnerUser"+ count, linkTokenInfo.getPartnerUserId());
        } catch (TokenException e) {
            Log.e(TAG, e.getMessage());
            //Below map entry is getting added only to handle case for AppTester Sandbox mode
            if(isSandBoxMode) {
                map.put("partnerUser" + count, link.getLinkId() + "-" + link.getLinkedTimestamp());
            }
        }
    }

    @Override
    public void onLinkUserAccountResponse(LinkUserAccountResponse linkUserAccountResponse) {
        Log.i(TAG,"onLinkUserAccountResponse : "+ linkUserAccountResponse.toString());
        Log.i(TAG,"onLinkUserAccountResponse.status :" + linkUserAccountResponse.getRequestStatus().toString());
        if(linkUserAccountResponse.getRequestStatus().toString().equals(RequestStatus.SUCCESSFUL.toString())) {
            Log.i(TAG, "onLinkUserAccountResponse.successCode :" + linkUserAccountResponse.getSuccessCode());
            showToast("Create Link User Account was successful with response status : " + linkUserAccountResponse.getRequestStatus().toString() + " ,successCode: " + linkUserAccountResponse.getSuccessCode());
        } else {
            showToast("Create Link User Account failed wirh response status : " + linkUserAccountResponse.getRequestStatus().toString()
            );
        }
    }

    @Override
    public void onShowLoginSelectionResponse(ShowLoginSelectionResponse showLoginSelectionResponse) {
        Log.i(TAG, "onShowLoginSelectionResponse: " + showLoginSelectionResponse);
        Log.i(TAG, "onShowLoginSelectionResponse.status :" + showLoginSelectionResponse.getRequestStatus());
        Log.i(TAG, "onShowLoginSelectionResponse.userSelection :" + showLoginSelectionResponse.getUserSelection());
        Log.i(TAG, "onShowLoginSelectionResponse.linkId :"+ showLoginSelectionResponse.getLinkId());
    }

    @Override
    public void onRecordMetricsEventResponse(RecordMetricsEventResponse recordMetricsEventResponse){
        Log.i(TAG, "RecordMetricsEventResponse: " + recordMetricsEventResponse);
        showToast("Metric Record Event response status : " +
                recordMetricsEventResponse.getRequestStatus().toString());
    }
}
