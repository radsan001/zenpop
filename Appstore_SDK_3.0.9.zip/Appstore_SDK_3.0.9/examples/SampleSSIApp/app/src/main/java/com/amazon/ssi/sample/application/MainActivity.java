package com.amazon.ssi.sample.application;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.amazon.device.simplesignin.SimpleSignInService;
import com.amazon.device.simplesignin.model.FailureReason;
import com.amazon.device.simplesignin.model.RequestId;
import com.amazon.device.simplesignin.model.SSIEvent;
import com.amazon.device.simplesignin.model.Token;
import com.amazon.device.simplesignin.model.request.LinkUserAccountRequest;
import com.amazon.device.simplesignin.model.request.SSIEventRequest;
import com.amazon.simplesignin.linktoken.LinkTokenV1Provider;
import com.amazon.simplesignin.types.common.GenerateLinkTokenV1Request;
import com.amazon.simplesignin.types.common.LinkTokenContainer;
import com.amazon.ssi.sample.application.constants.JugglerConstants;
import com.amazon.ssi.sample.application.databinding.ActivityMainBinding;
import com.amazon.ssi.sample.application.token.provider.LinkTokenProviderFactory;
import com.amazon.ssi.sample.application.token.provider.RequestContext;
import com.amazon.ssi.sample.application.token.receiver.ResponseHandlerImpl;

import org.apache.commons.lang.StringUtils;

import java.security.Security;

public class MainActivity extends AppCompatActivity {

    static {
        Security.removeProvider("BC");
        Security.insertProviderAt(new org.spongycastle.jce.provider.BouncyCastleProvider(), 1);
    }

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    String idpName = JugglerConstants.idpName;
    ResponseHandlerImpl responseHandler;
    private static final String TAG = JugglerConstants.TAG;
    private EditText uname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        responseHandler = new ResponseHandlerImpl();
        responseHandler.setAppContext(getApplicationContext());
        SimpleSignInService.registerResponseHandler(this, responseHandler);
        /**
         * create link button
         */
        Button createLinkButton = (Button) findViewById(R.id.button_create_link);
        getSSILink();
        uname = findViewById(R.id.text_create_link);
        createLinkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createSSILink(uname.getText().toString());
            }
        });
        /**
         * Get link button
         */
        Button getLinkButton = (Button) findViewById(R.id.button_get_link);
        getLinkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getSSILink();
            }
        });

        /**
         * Login Success Button
         */
        Button loginSuccess = (Button) findViewById(R.id.button_login_success);
        loginSuccess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i(TAG, "###########recordMetricsEvent for Login Success: initiating request #############");
                SimpleSignInService.recordMetricEvent(new SSIEventRequest(SSIEvent.LOGIN_SUCCESS));
            }
        });

        Spinner spinnerFailureReasons = findViewById(R.id.spinner_failure_reasons);

        spinnerFailureReasons.setAdapter(new ArrayAdapter<FailureReason>(this,
                android.R.layout.simple_spinner_item, FailureReason.values()));
        /**
         * Login Failure Button
         */
        Button loginFailure = (Button) findViewById(R.id.button_login_failure);
        loginFailure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i(TAG, "###########recordMetricsEvent for Login Failure: initiating request #############");
                SimpleSignInService.recordMetricEvent(new SSIEventRequest(SSIEvent.LOGIN_FAILURE,
                        (FailureReason) spinnerFailureReasons.getSelectedItem()));
            }
        });
        /**
         * Manual Sign In button
         */
        Button manualSignIn = (Button) findViewById(R.id.button_manual_sign_in);
        manualSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i(TAG, "###########recordMetricsEvent for Manual Sign In: initiating request #############");
                SimpleSignInService.recordMetricEvent(new SSIEventRequest(SSIEvent.MANUAL_SIGNIN_SELECTED));
            }
        });

    }


    /**
     * 1. Create new token
     * 2. Create SSI link account request object
     * 3. Invoke Createlink method of SSI SDK
     */
    private void createSSILink(String userName) {
        try {
            if (StringUtils.isEmpty(userName)) {
                userName = JugglerConstants.userName;
            }
            // PartnerUserId is an opaque identifier used to represent your user’s identity to Amazon.
            // This identifier is used in de-duplication of account linking requests
            // if the app account is already linked with their Amazon  account.
            String partnerUserId = userName;
            Log.i(TAG, "###########createLink:  initiating request ############# with userName :" + userName);
            LinkTokenV1Provider linkTokenV1Provider = LinkTokenProviderFactory.getLinkedTokenV1Provider();
            RequestContext requestContext = new RequestContext();

            Log.i(TAG, "###########AmazonDirect UserID:  #############" + responseHandler.directedAmazonUserId);

            if (StringUtils.isEmpty(responseHandler.directedAmazonUserId)) {
                responseHandler.showToast("Please call GetUserLinks first to fetch AmazonUserId");
                return;
            }
            GenerateLinkTokenV1Request request = GenerateLinkTokenV1Request.builder()
                    .directedAmazonUserId(responseHandler.directedAmazonUserId)
                    .partnerUserId(partnerUserId)
                    .customFields(null) //Map of custom fields
                    .requestContext(requestContext)
                    .build();
            LinkTokenContainer linkTokenContainer = linkTokenV1Provider.generateLinkToken(request);


            LinkUserAccountRequest linkUserAccountRequest = new LinkUserAccountRequest();
            linkUserAccountRequest.setIdentityProviderName(idpName);
            linkUserAccountRequest.setPartnerUserId(partnerUserId);
            linkUserAccountRequest.setUserLoginName(userName);
            Token token = new Token();
            token.setToken(linkTokenContainer.getLinkToken().getToken());
            token.setSchema(linkTokenContainer.getLinkToken().getTokenSchema().toString());
            linkUserAccountRequest.setLinkToken(token);
            linkUserAccountRequest.setLinkSigningKey(linkTokenContainer.getLinkSigningKeyEncrypted());

            RequestId requestId = SimpleSignInService.linkUserAccount(linkUserAccountRequest);
            Log.i(TAG, "createLink: linkUserAccount complete requestId   " + requestId);

        } catch (Exception ex) {
            Log.e(TAG, "createLink: Exception ", ex);
        }
    }

    /**
     * Get existing linked accounts for given provider and current Amazon customer
     * using app
     */
    private void getSSILink() {
        Log.i(TAG, "###########getSSILink:  initiating request #############");
        RequestId requestId = SimpleSignInService.getUserAndLinks(idpName);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
}