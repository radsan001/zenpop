package com.amazon.sample.drm;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class LicensingPromptHelper {

    private static final String TAG = LicensingPromptHelper.class.getSimpleName();

    // https://developer.amazon.com/blogs/post/Tx3A1TVL67TB24B/Linking-To-the-Amazon-Appstore-for-Android.html
    private static final String AMAZON_APPSTORE_APP_DETAIL_DEEP_LINK = "amzn://apps/android?p=";

    public static void showLicenseFailurePrompt(final Context context,
                                                final LicenseVerificationPromptContent licenseVerificationPromptContent) {
        // custom dialog that represents License Verification Failure
        final Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.license_verification_failure_dialog);
        dialog.setTitle(R.string.license_failure_title);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
        } else {
            dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
        }

        // Handle the scenario where customer presses back button while License Failure Dialog is launched.
        handleBackButtonPressed(dialog);

        // if dialogButtonShutDown is clicked, shut-down the Application
        final Button dialogButtonShutDown = (Button) dialog.findViewById(R.id.dialogButtonShutDown);
        handleShutDownButtonPressed(dialogButtonShutDown);

        final TextView description = dialog.findViewById(R.id.description_text);
        final Button dialogButtonDetailPage = dialog.findViewById(R.id.dialogButtonDetailPage);
        if (licenseVerificationPromptContent == LicenseVerificationPromptContent.DEEP_LINK) {
            // set the custom dialog description
            description.setText(R.string.description_buy_app);
            // Display the button that will allow customer to navigate to App Detail Page
            handleDetailPageButtonPressed(dialogButtonDetailPage, context);
        } else {
            // set the custom dialog description
            description.setText(R.string.description_shutdown_app);
        }

        dialog.show();
    }

    private static void handleBackButtonPressed(final Dialog dialog) {
        dialog.setCanceledOnTouchOutside(false);
        // Shut Down the Application when Cancel/Back button is pressed.
        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                // TODO : Perform any Application specific tasks that need to be performed before Application shutdown.
                Log.d(TAG, "Customer is not licensed to use the Application, Shutting down the Application");
                android.os.Process.killProcess(android.os.Process.myPid());
            }
        });
    }

    private static void handleShutDownButtonPressed(final Button dialogButtonShutDown) {
        dialogButtonShutDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v) {
                // TODO : Perform any Application specific tasks that need to be performed before Application shutdown.
                Log.d(TAG, "Customer is not licensed to use the Application, Shutting down the Application");
                android.os.Process.killProcess(android.os.Process.myPid());
            }
        });
    }

    private static void handleDetailPageButtonPressed(final Button dialogButtonDetailPage, final Context context) {
        dialogButtonDetailPage.setVisibility(View.VISIBLE);
        // if button is clicked, deep-link to Amazon Appstore App Detail Page
        dialogButtonDetailPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v) {
                // TODO : Perform any Application specific tasks that need to be performed before Application shutdown.
                Log.d(TAG, "Customer is not licensed to use the Application, Shutting down the Application");
                deepLinkToAppstore(context);
            }
        });
    }

    private static void deepLinkToAppstore(final Context context) {
        Log.d(TAG, "Attempting to deep link to Amazon Appstore.");
        final Intent intent = createDeepLinkIntent(context);
        startActivityIfPossible(context, intent);
    }

    private static Intent createDeepLinkIntent(final Context context) {
        final String packageName = context.getPackageName();
        final String uriString = AMAZON_APPSTORE_APP_DETAIL_DEEP_LINK + packageName;
        return new Intent(Intent.ACTION_VIEW, Uri.parse(uriString));
    }

    private static void startActivityIfPossible(final Context context, final Intent intent) {
        if (!canResolve(context, intent)) {
            Log.d(TAG, "Customer is not licensed to use the Application, Shutting down the Application");
            android.os.Process.killProcess(android.os.Process.myPid());
            return;
        }
        final AsyncTask<Intent, Void, Void> activityTask = new StartActivityTask(context);
        activityTask.execute(intent);
    }

    private static boolean canResolve(final Context context, final Intent intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        final PackageManager packageManager = context.getPackageManager();
        return intent.resolveActivity(packageManager) != null;
    }

    private static class StartActivityTask extends AsyncTask<Intent, Void, Void> {
        private final Context context;

        private StartActivityTask(final Context context) {
            this.context = context;
        }

        @Override
        public Void doInBackground( final Intent... intents) {
            context.startActivity(intents[0]);
            return null;
        }

        @Override
        public void onPostExecute( Void ignored) {
            android.os.Process.killProcess(android.os.Process.myPid());
        }
    }
}
