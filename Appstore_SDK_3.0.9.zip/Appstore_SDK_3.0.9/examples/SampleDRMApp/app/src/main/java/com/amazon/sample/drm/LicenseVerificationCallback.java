package com.amazon.sample.drm;

import android.content.Context;
import android.util.Log;
import com.amazon.device.drm.model.LicenseResponse;


public class LicenseVerificationCallback implements com.amazon.device.drm.LicensingListener {

    final private MainActivity mainActivity;
    final private Context context;

    public LicenseVerificationCallback(final MainActivity mainActivity ) {
        this.mainActivity = mainActivity;
        this.context = mainActivity.getApplicationContext();
    }


    private static final String TAG = LicenseVerificationCallback.class.getSimpleName();

    @Override
    public void onLicenseCommandResponse(final LicenseResponse licenseResponse) {
        final LicenseResponse.RequestStatus status = licenseResponse.getRequestStatus();
        mainActivity.setLicenseResponseStatus(status.name());
        switch (status) {
            case LICENSED:
                Log.d(TAG, "LicenseResponse status: " + status);
                break;
            case NOT_LICENSED:
                Log.d(TAG, "LicenseResponse status: " + status);
            case EXPIRED:
                Log.d(TAG, "LicenseResponse status: " + status);
                LicensingPromptHelper.showLicenseFailurePrompt(context, LicenseVerificationPromptContent.DEEP_LINK);
                break;
            case ERROR_VERIFICATION:
                Log.d(TAG, "LicenseResponse status: " + status);
            case ERROR_INVALID_LICENSING_KEYS:
                Log.d(TAG, "LicenseResponse status: " + status);
            case UNKNOWN_ERROR:
                Log.d(TAG, "LicenseResponse status: " + status);
                LicensingPromptHelper.showLicenseFailurePrompt(context, LicenseVerificationPromptContent.SHUT_DOWN);
        }
    }
}
