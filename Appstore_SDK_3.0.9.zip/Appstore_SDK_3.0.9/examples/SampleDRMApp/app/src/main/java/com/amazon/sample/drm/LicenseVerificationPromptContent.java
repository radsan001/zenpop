package com.amazon.sample.drm;

public enum LicenseVerificationPromptContent {

    /**
     * Customer is not entitled to the Apllication, Redirect the customer
     * to Amazon Appstore App Detail Page to allow him to purchase the Application
     */
    DEEP_LINK,

    /**
     * There was an error in verifying the license of the customer. Shutting Down
     * the Application.
     */
    SHUT_DOWN;
}