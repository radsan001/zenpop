package com.amazon.sample.drm;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

import com.amazon.device.drm.LicensingService;

/**
 * Main activity for DRM Sample Code
 *
 * This is the main activity for this project.
 */
public class MainActivity extends Activity {

    /**
     * Do license verification setp by calling verifyLicense API.
     */
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupApplicationSpecificOnCreate();
        LicensingService.verifyLicense(getApplicationContext(), new LicenseVerificationCallback(this));
    }

    // ///////////////////////////////////////////////////////////////////////////////////////
    // ////////////////////////// Application specific code below
    // ////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////////////////

    private static final String TAG = "SampleDRMApp";
    protected TextView licenseResponseStatusTextView;
    protected Handler guiThreadHandler;

    /**
     * Setup application specific things, called from onCreate()
     */
    protected void setupApplicationSpecificOnCreate() {
        setContentView(R.layout.activity_main);
        licenseResponseStatusTextView = (TextView) findViewById(R.id.getlicense_response_status);
        guiThreadHandler = new Handler();
    }

    public void setLicenseResponseStatus(final String licenseResponseStatus) {
        guiThreadHandler.post(new Runnable() {
            @Override
            public void run() {
                licenseResponseStatusTextView.setText(getString(R.string.license_response_status) + licenseResponseStatus);
                licenseResponseStatusTextView.setVisibility(View.VISIBLE);
            }
        });
    }
}
