package com.amazon.sample.iap.subscription;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.amazon.device.iap.PurchasingService;
import com.amazon.device.iap.model.RequestId;

/**
 * Main activity for IAP subscriptions Sample Code
 * 
 * This is the app activity for this project.
 */
public class MainActivity extends Activity {
    private SampleIapManager sampleIapManager;

    /**
     * Setup IAP SDK and other UI related objects specific to this sample
     * application.
     */
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupApplicationSpecificOnCreate();
        setupIAPOnCreate();
    }

    /**
     * Setup for IAP SDK called from onCreate. Sets up {@link SampleIapManager}
     * to handle InAppPurchasing logic and {@link SamplePurchasingListener} for
     * listening to IAP API callbacks
     */
    private void setupIAPOnCreate() {
        sampleIapManager = new SampleIapManager(this);
        final SamplePurchasingListener purchasingListener = new SamplePurchasingListener(sampleIapManager);
        Log.d(TAG, "onCreate: registering PurchasingListener");
        PurchasingService.registerListener(this.getApplicationContext(), purchasingListener);

    }

    /**
     * Calls {@link PurchasingService#getUserData()} to get current Amazon
     * user's data
     * and {@link PurchasingService#getProductData(Set)} to get the product
     * availability
     * and {@link PurchasingService#getPurchaseUpdates(boolean)} to
     * get recent purchase updates
     */
    @Override
    protected void onResume() {
        super.onResume();
        sampleIapManager.activate();
        Log.d(TAG, "onResume: call getUserData");
        PurchasingService.getUserData();
        Log.d(TAG, "onResume: call getProductData for base + add-on skus: " +
                Arrays.toString(MySku.values()));
        final Set<String> productSkus = new HashSet<>();
        for (final MySku mySku : MySku.values()) {
            productSkus.add(mySku.getSku());
        }
        PurchasingService.getProductData(productSkus);
        Log.d(TAG, "onResume: getPurchaseUpdates");
        PurchasingService.getPurchaseUpdates(false);

    }

    /**
     * Deactivate Sample IAP manager on app activity's Pause event
     */
    @Override
    protected void onPause() {
        super.onPause();
        sampleIapManager.deactivate();
    }

    /**
     * Click handler invoked when user clicks button to buy magazine
     * subscription. This method calls
     * {@link PurchasingService#purchase(String)} with the SKU to initialize the
     * purchase from Amazon Appstore
     */
    public void onBuyMagazineClick(final View view) {
        final RequestId requestId = PurchasingService.purchase(MySku.MY_MAGAZINE_SUBS_GOLD_MONTHLY.getSku());
        Log.d(TAG, "onBuyMagazineClick: requestId (" + requestId + ")");
    }

    /**
     * Click handler for "Buy Premium Add-On". Add-Ons use the same
     * {@link PurchasingService#purchase(String)} API as base
     * subscriptions; Appstore validates the active-base requirement
     * server-side.
     */
    public void onBuyAddonClick(final View view) {
        final RequestId requestId = PurchasingService.purchase(MySku.MY_MAGAZINE_ADDON_PREMIUM_MONTHLY.getSku());
        Log.d(TAG, "onBuyAddonClick: requestId (" + requestId + ")");
    }

    // ///////////////////////////////////////////////////////////////////////////////////////
    // ////////////////////////// Application specific code below
    // ////////////////////////////
    // ///////////////////////////////////////////////////////////////////////////////////////

    private static final String TAG = "SampleSubscriptionsApp";

    private Handler guiThreadHandler;

    // Button to subscribe magazine
    private Button buyMagazineButton;

    // TextView shows whether user is subscribed to magazine
    private TextView isSubscriptionEnabled;

    // Button to purchase Add-On
    private Button buyAddonButton;

    // TextView shows whether user owns the Add-On
    private TextView isAddonEnabled;

    /**
     * Setup application specific things, called from onCreate()
     */
    private void setupApplicationSpecificOnCreate() {
        setContentView(R.layout.activity_main);

        buyMagazineButton = (Button) findViewById(R.id.buy_magazine_button);
        buyAddonButton = (Button) findViewById(R.id.buy_addon_button);

        resetApplication();

        guiThreadHandler = new Handler();
    }

    /**
     * Show "Subscription Disabled" text in gray color to indicate user is not
     * subscribed to this magazine initially
     */
    private void resetApplication() {
        isSubscriptionEnabled = (TextView) findViewById(R.id.is_magazine_enabled);
        isSubscriptionEnabled.setText(R.string.subscription_disabled);
        isSubscriptionEnabled.setTextColor(Color.GRAY);
        isSubscriptionEnabled.setBackgroundColor(Color.WHITE);

        isAddonEnabled = (TextView) findViewById(R.id.is_addon_enabled);
        isAddonEnabled.setText(R.string.addon_disabled);
        isAddonEnabled.setTextColor(Color.GRAY);
        isAddonEnabled.setBackgroundColor(Color.WHITE);
    }

    /**
     * Show message on UI
     *
     * @param message The message to be shown
     */
    public void showMessage(final String message) {
        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
    }

    /**
     * Set the magazine subscription button status on UI.
     *
     * The buy button stays enabled while the SKU is in the catalog
     * regardless of ownership. Letting a second tap reach the SDK
     * surfaces ALREADY_PURCHASED.
     *
     * @param productAvailable true if the product is in the catalog and a user is logged in
     * @param userCanSubscribe true if the user does not currently own the subscription
     */
    public void setMagazineSubsAvail(final boolean productAvailable, final boolean userCanSubscribe) {
        guiThreadHandler.post(new Runnable() {
            @Override
            public void run() {
                if (productAvailable) {
                    enableBuyMagazineButton();
                    if (userCanSubscribe) {
                        disableMagazineSubscriptionInView();
                    } else {
                        enableMagazineSubscriptionInView();
                    }
                } else {
                    disableMagazineSubscriptionInView();
                    disableBuyMagazineButton();
                }
            }
        });
    }

    /**
     * Set the Add-On purchase UI state.
     *
     * The buy button stays enabled while the SKU is in the catalog
     * regardless of ownership. Letting a second tap reach the SDK
     * surfaces ALREADY_PURCHASED.
     *
     * @param addonAvailable true if the Add-On is in the catalog and a user is logged in
     * @param addonOwned     true if the customer already holds an active Add-On receipt
     */
    public void setAddonSubsAvail(final boolean addonAvailable, final boolean addonOwned) {
        guiThreadHandler.post(new Runnable() {
            @Override
            public void run() {
                buyAddonButton.setEnabled(addonAvailable);
                if (addonOwned) {
                    enableAddonInView();
                } else {
                    disableAddonInView();
                }
            }
        });
    }

    /**
     * Disable "Buy Magazine Subscription" button
     */
    private void disableBuyMagazineButton() {
        buyMagazineButton.setEnabled(false);
    }

    /**
     * Enable "Buy Magazine Subscription" button
     */
    private void enableBuyMagazineButton() {
        buyMagazineButton.setEnabled(true);
    }

    /**
     * Show Subscription as enabled in view
     */
    private void enableMagazineSubscriptionInView() {
        isSubscriptionEnabled.setText(R.string.subscription_enabled);
        isSubscriptionEnabled.setTextColor(Color.BLUE);
        isSubscriptionEnabled.setBackgroundColor(Color.YELLOW);
    }

    /**
     * Show Subscription as disabled in view
     */
    protected void disableMagazineSubscriptionInView() {
        isSubscriptionEnabled.setText(R.string.subscription_disabled);
        isSubscriptionEnabled.setTextColor(Color.GRAY);
        isSubscriptionEnabled.setBackgroundColor(Color.WHITE);
    }

    /**
     * Show the Add-On as enabled in the view.
     */
    private void enableAddonInView() {
        isAddonEnabled.setText(R.string.addon_enabled);
        isAddonEnabled.setTextColor(Color.BLUE);
        isAddonEnabled.setBackgroundColor(Color.YELLOW);
    }

    /**
     * Show the Add-On as disabled in the view.
     */
    private void disableAddonInView() {
        isAddonEnabled.setText(R.string.addon_disabled);
        isAddonEnabled.setTextColor(Color.GRAY);
        isAddonEnabled.setBackgroundColor(Color.WHITE);
    }
}
