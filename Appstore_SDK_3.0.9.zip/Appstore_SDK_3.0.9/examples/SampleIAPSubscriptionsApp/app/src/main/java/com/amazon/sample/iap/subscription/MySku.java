package com.amazon.sample.iap.subscription;

import java.util.Arrays;
import java.util.List;

/**
 *
 * MySku enum contains all In App Purchase products definition that the sample
 * app will use. The product definition includes two properties: "SKU" and
 * "Available Marketplace".
 *
 */
public enum MySku {

    // Base Subscription
    MY_MAGAZINE_SUBS_GOLD_MONTHLY("com.amazon.sample.iap.subscription.mymagazine.gold.month",
            Arrays.asList("AU", "BR", "CA", "CN", "DE", "ES", "FR", "GB", "IN", "IT",
            "JP", "MX", "US")),

    // Add-On - associations are configured at TERM level
    // Monthly Add-On attaches to the monthly base
    MY_MAGAZINE_ADDON_PREMIUM_MONTHLY("com.amazon.sample.iap.subscription.mymagazine.addon.premium.monthly",
            Arrays.asList("AU", "BR", "CA", "CN", "DE", "ES", "FR", "GB", "IN", "IT",
            "JP", "MX", "US"));

    private final String sku;
    private final List<String> availableMarketplaces;

    /**
     * Returns the Sku string of the MySku object
     * @return sku
     */
    public String getSku() {
        return this.sku;
    }

    /**
     * Returns the Available Marketplace of the MySku object
     * @return list of available marketplaces
     */
    public List<String> getAvailableMarketplaces() {
        return this.availableMarketplaces;
    }

    MySku(final String sku, final List<String> availableMarketplaces) {
        this.sku = sku;
        this.availableMarketplaces = availableMarketplaces;
    }

    /**
     * Returns the MySku object from the specified Sku and marketplace value.
     * @param sku sku in string format
     * @param marketplace marketplace
     * @return MySku object corresponding to the sku and marketplace if possible, null otherwise
     */
    public static MySku fromSku(final String sku, final String marketplace) {
        if (MY_MAGAZINE_SUBS_GOLD_MONTHLY.getSku().equals(sku) && (null == marketplace || MY_MAGAZINE_SUBS_GOLD_MONTHLY.getAvailableMarketplaces()
                .contains(marketplace.toUpperCase()))) {
            return MY_MAGAZINE_SUBS_GOLD_MONTHLY;
        }
        
        if (MY_MAGAZINE_ADDON_PREMIUM_MONTHLY.getSku().equals(sku) && (null == marketplace || MY_MAGAZINE_ADDON_PREMIUM_MONTHLY.getAvailableMarketplaces()
                .contains(marketplace.toUpperCase()))) {
            return MY_MAGAZINE_ADDON_PREMIUM_MONTHLY;
        }
        return null;
    }

}
