package com.amazon.sample.iap.subscription;

import java.util.List;
import java.util.Map;
import java.util.Set;

import android.util.Log;

import com.amazon.device.iap.PurchasingListener;
import com.amazon.device.iap.PurchasingService;
import com.amazon.device.iap.model.FulfillmentResult;
import com.amazon.device.iap.model.Product;
import com.amazon.device.iap.model.PurchaseUpdatesResponse;
import com.amazon.device.iap.model.Receipt;
import com.amazon.device.iap.model.UserData;

/**
 * This is a sample of how an application may handle InAppPurchasing. The major
 * functions includes
 * <ul>
 * <li>Simple user and subscription history management</li>
 * <li>Grant subscription purchases</li>
 * <li>Enable/disable subscribe from GUI</li>
 * <li>Save persistent subscriptions data into SQLite database</li>
 * </ul>
 * 
 * 
 */
public class SampleIapManager {
    private static final String TAG = "SampleIAPManager";
    private final MainActivity mainActivity;
    private final SubscriptionDataSource dataSource;

    private volatile boolean magazineSubsAvailable;
    private volatile boolean addonSubsAvailable;
    private volatile UserIapData userIapData;

    public SampleIapManager(final MainActivity mainActivity) {
        this.mainActivity = mainActivity;
        this.dataSource = new SubscriptionDataSource(mainActivity.getApplicationContext());
    }

    /**
     * Method to set the app's amazon user id and marketplace from IAP SDK
     * responses.
     * 
     * @param newAmazonUserId userId for the new user
     * @param newAmazonMarketplace marketplace of the user
     */
    public void setAmazonUserId(final String newAmazonUserId, final String newAmazonMarketplace) {
        // Reload everything if the Amazon user has changed.
        if (newAmazonUserId == null) {
            // A null user id typically means there is no registered Amazon
            // account.
            if (userIapData != null) {
                userIapData = null;
                refreshMagazineSubsAvailability();
            }
        } else if (userIapData == null || !newAmazonUserId.equals(userIapData.getAmazonUserId())) {
            // If there was no existing Amazon user then either no customer was
            // previously registered or the application has just started.

            // If the user id does not match then another Amazon user has
            // registered.
            userIapData = new UserIapData(newAmazonUserId, newAmazonMarketplace);
            refreshMagazineSubsAvailability();
        }
    }

    /**
     * Enable the magazine subscription.
     * 
     * @param productData product data returned by {@link PurchasingService#getProductData}
     */
    public void enablePurchaseForSkus(final Map<String, Product> productData) {
        if (productData.containsKey(MySku.MY_MAGAZINE_SUBS_GOLD_MONTHLY.getSku())) {
            magazineSubsAvailable = true;
        }
        if (productData.containsKey(MySku.MY_MAGAZINE_ADDON_PREMIUM_MONTHLY.getSku())) {
            addonSubsAvailable = true;
        }
    }

    /**
     * Disable the magazine subscription.
     *
     * @param unavailableSkus unavailable skus returned by {@link PurchasingService#getProductData}
     */
    public void disablePurchaseForSkus(final Set<String> unavailableSkus) {
        if (unavailableSkus.contains(MySku.MY_MAGAZINE_SUBS_GOLD_MONTHLY.getSku())) {
            magazineSubsAvailable = false;
            // reasons for product not available can be:
            // * Item not available for this country
            // * Item pulled off from Appstore by developer
            // * Item pulled off from Appstore by Amazon
            mainActivity.showMessage("the magazine subscription product isn't available now! ");
        }
        if (unavailableSkus.contains(MySku.MY_MAGAZINE_ADDON_PREMIUM_MONTHLY.getSku())) {
            addonSubsAvailable = false;
            mainActivity.showMessage("the premium add-on product isn't available now! ");
        }
    }

    /**
     * This method contains the business logic to fulfill the customer's
     * purchase based on the receipt received from InAppPurchase SDK's
     * {@link PurchasingListener#onPurchaseResponse} or
     * {@link PurchasingListener#onPurchaseUpdatesResponse(PurchaseUpdatesResponse)} method.
     * 
     * 
     * @param receipt Receipt associated with subscription purchase
     * @param userData Data of user who purchased the subscription
     */
    public void handleSubscriptionPurchase(final Receipt receipt, final UserData userData) {
        try {
            if (receipt.isCanceled()) {
                // Check whether this receipt is for an expired or canceled
                // subscription
                revokeSubscription(receipt, userData.getUserId());
            } else {
                // We strongly recommend that you verify the receipt on
                // server-side.
                if (!verifyReceiptFromYourService(receipt.getReceiptId(), userData)) {
                    // if the purchase cannot be verified,
                    // show relevant error message to the customer.
                    mainActivity.showMessage("Purchase cannot be verified, please retry later.");
                    return;
                }
                grantSubscriptionPurchase(receipt, userData);
            }
        } catch (final Throwable e) {
            mainActivity.showMessage("Purchase cannot be completed, please retry");
        }

    }

    /**
     * Dispatch a Receipt to one of the four {@link FulfillmentResult}s:
     *
     *   FULFILLED         — entitlement delivered
     *   UNAVAILABLE       — partner cannot fulfill this receipt
     *   NOT_ELIGIBLE      — partner-defined eligibility check failed
     *   EXISTING_PURCHASE — duplicate of a receipt already owned
     *
     * Cancellation statuses are final and trigger a server-side refund.
     */
    private void grantSubscriptionPurchase(final Receipt receipt, final UserData userData) {

        final String termSku = receipt.getTermSku();
        final MySku mySku = MySku.fromSku(termSku, userIapData.getAmazonMarketplace());

        // Verify that the SKU is still applicable.
        if (mySku != MySku.MY_MAGAZINE_SUBS_GOLD_MONTHLY
                && mySku != MySku.MY_MAGAZINE_ADDON_PREMIUM_MONTHLY) {
            Log.w(TAG, "SKU [" + termSku + "] is not in this app's catalog; emitting UNAVAILABLE");
            markReceiptUnavailable(receipt.getReceiptId());
            return;
        }

        // 1) Partner-defined unavailable check. Default returns
        //    true — replace with your own check.
        if (!canPartnerFulfillReceipt(mySku, receipt, userData)) {
            Log.w(TAG, "Partner cannot fulfill SKU [" + termSku + "]; emitting UNAVAILABLE");
            markReceiptUnavailable(receipt.getReceiptId());
            return;
        }

        // 2) Owned under a different active receipt. Excluding the current
        //    receiptId is critical: the SDK redelivers each receipt ~250 ms
        //    later via onPurchaseUpdatesResponse
        if (isExistingPurchase(receipt, termSku)) {
            Log.w(TAG, "Customer already owns SKU [" + termSku + "]; notifying EXISTING_PURCHASE");
            markReceiptExistingPurchase(receipt.getReceiptId());
            return;
        }

        // 3) Partner-defined eligibility check. Appstore validates the
        //    active-base rule server-side at purchase() time; this
        //    branch is for partner-specific rules the server can't know
        //    (loyalty tier, fraud flags, region rules, etc.). Default
        //    returns true — replace with your own check.
        if (!isReceiptEligibleForPartner(mySku, receipt, userData)) {
            Log.w(TAG, "Partner check rejected SKU [" + termSku + "]; emitting NOT_ELIGIBLE");
            markReceiptNotEligible(receipt.getReceiptId());
            return;
        }

        // 4) Happy path. FULFILLED is non-final so re-emit on redelivery is a no-op.
        try {
            Log.i(TAG, "SKU [" + termSku + "] fulfilled; notifying FULFILLED");
            markReceiptFulfilled(receipt, userData.getUserId());
        } catch (final Throwable e) {
            // Do not emit a cancellation status on a transient failure —
            // those are final and would permanently refund a legitimate
            // purchase. Letting it propagate lets getPurchaseUpdates retry.
            Log.e(TAG, "Failed to grant subscription purchase, with error " + e.getMessage());
        }

    }

    /**
     * Method to handle receipt
     * 
     * @param requestId requestId associated with purchase
     * @param receipt receipt returned by Amazon for the purchase
     * @param userData data of user who performed the purchase
     */
    public void handleReceipt(final String requestId, final Receipt receipt, final UserData userData) {
        switch (receipt.getProductType()) {
        case CONSUMABLE:
            // check consumable sample for how to handle consumable purchases
            break;
        case ENTITLED:
            // check entitlement sample for how to handle consumable purchases
            break;
        case SUBSCRIPTION:
            handleSubscriptionPurchase(receipt, userData);
            break;
        }
    }

    /**
     * Show purchase failed message
     * @param sku sku for which purchase failed
     */
    public void showPurchaseFailedMessage(final String sku) {
        mainActivity.showMessage("Purchase failed!");
    }

    public UserIapData getUserIapData() {
        return this.userIapData;
    }

    public boolean isMagazineSubsAvailable() {
        return magazineSubsAvailable;
    }

    public void setMagazineSubsAvailable(final boolean magazineSubsAvailable) {
        this.magazineSubsAvailable = magazineSubsAvailable;
    }

    public void setAddonSubsAvailable(final boolean addonSubsAvailable) {
        this.addonSubsAvailable = addonSubsAvailable;
    }

    /**
     * Disable all magazine subscriptions on UI
     */
    public void disableAllPurchases() {
        this.setMagazineSubsAvailable(false);
        this.setAddonSubsAvailable(false);
        refreshMagazineSubsAvailability();
    }

    /**
     * Refresh the buy buttons and ownership status text.
     */
    public void refreshMagazineSubsAvailability() {
        final UserIapData snapshot = this.userIapData;
        final boolean available = magazineSubsAvailable && snapshot != null;
        mainActivity.setMagazineSubsAvail(available,
                                          snapshot != null && !snapshot.isSubsActiveCurrently());

        final boolean addonOwned = snapshot != null && snapshot.isAddonActiveCurrently();
        final boolean addonAvailable = addonSubsAvailable && snapshot != null;
        mainActivity.setAddonSubsAvail(addonAvailable, addonOwned);
    }

    /**
     * Gracefully close the database when the main activity's onStop and
     * onDestroy
     * 
     */
    public void deactivate() {
        dataSource.close();

    }

    /**
     * Connect to the database when main activity's onStart and onResume
     */
    public void activate() {
        dataSource.open();

    }

    /**
     * Reload the subscription history from database
     */
    public void reloadSubscriptionStatus() {
        final List<SubscriptionRecord> subsRecords = dataSource.getSubscriptionRecords(userIapData.getAmazonUserId());
        userIapData.setSubscriptionRecords(subsRecords);
        userIapData.reloadSubscriptionStatus();
        refreshMagazineSubsAvailability();
    }

    /**
     * 
     * This sample app includes a simple SQLite implementation for save
     * subscription purchase detail locally.
     * 
     * We strongly recommend that you save the purchase information on a server.
     * 
     * 
     * 
     * @param receipt  receipt associated with the purchase
     * @param userId app user Id who made the purchase
     */
    private void saveSubscriptionRecord(final Receipt receipt, final String userId) {
        // TODO replace with your own implementation

        dataSource
            .insertOrUpdateSubscriptionRecord(receipt.getReceiptId(),
                                              userId,
                                              receipt.getPurchaseDate().getTime(),
                                              receipt.getCancelDate() == null ? SubscriptionRecord.TO_DATE_NOT_SET
                                                      : receipt.getCancelDate().getTime(),
                                              receipt.getTermSku());

    }

    /**
     * We strongly recommend verifying the receipt on your own server side
     * first. The server side verification ideally should include checking with
     * Amazon RVS (Receipt Verification Service) to verify the receipt details.
     * 
     * @see <a href=
     *      "https://developer.amazon.com/appsandservices/apis/earn/in-app-purchasing/docs/rvs"
     *      >Appstore's Receipt Verification Service</a>
     * 
     * @param receiptId receiptId to be verified
     * @param userData data of the user who is associated with the receiptId
     * @return true if receipt is valid, false otherwise
     */
    private boolean verifyReceiptFromYourService(final String receiptId, final UserData userData) {
        // TODO Add your own server side accessing and verification code
        return true;
    }

    /**
     * Private method to revoke a subscription purchase from the customer
     * 
     * Please implement your application-specific logic to handle the revocation
     * of a subscription purchase.
     * 
     * 
     * @param receipt receipt associated with subscription purchase
     * @param userId userId associated with the subscription purchase
     */
    private void revokeSubscription(final Receipt receipt, final String userId) {
        final String receiptId = receipt.getReceiptId();
        dataSource.cancelSubscription(receiptId, receipt.getCancelDate().getTime());

    }

    /**
     * True if the customer holds this term SKU under a different
     * active receipt.
     *
     * Reuses {@link SubscriptionRecord#isActiveNow()} for the liveness check.
     * Production code should additionally verify with RVS, since local
     * state can lag a server-side cancel or expiry.
     */
    private boolean isExistingPurchase(final Receipt receipt, final String termSku) {
        if (userIapData == null || userIapData.getSubscriptionRecords() == null) {
            return false;
        }
        final String currentReceiptId = receipt.getReceiptId();
        for (final SubscriptionRecord record : userIapData.getSubscriptionRecords()) {
            if (!record.isActiveNow()) {
                continue;
            }
            if (currentReceiptId.equals(record.getAmazonReceiptId())) {
                continue;
            }
            if (termSku.equals(record.getSku())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Partner-defined unavailable hook. Returns true by
     * default. Replace with whatever signal the integration requires —
     * any reason the app cannot deliver this receipt at all. Returning false
     * routes the receipt to {@link #markReceiptUnavailable(String)}.
     */
    private boolean canPartnerFulfillReceipt(final MySku mySku, final Receipt receipt, final UserData userData) {
        return true;
    }

    /**
     * Partner-defined eligibility hook. Returns true by default; replace
     * with whatever check the integration requires. Returning false
     * from this method routes the receipt to {@link #markReceiptNotEligible(String)}.
     */
    private boolean isReceiptEligibleForPartner(final MySku mySku, final Receipt receipt, final UserData userData) {
        return true;
    }

    /**
     * Emit {@link FulfillmentResult#FULFILLED} for a receipt and persist
     * it locally as the customer's active entitlement. Call this once
     * the partner app has actually delivered the entitlement. FULFILLED
     * is the only non-final status — safe to re-emit on SDK redelivery.
     */
    private void markReceiptFulfilled(final Receipt receipt, final String userId) {
        saveSubscriptionRecord(receipt, userId);
        PurchasingService.notifyFulfillment(receipt.getReceiptId(), FulfillmentResult.FULFILLED);
    }

    /**
     * Emit {@link FulfillmentResult#UNAVAILABLE} for a receipt and
     * record the cancel locally. Call this when the partner app cannot
     * fulfill the SKU at all. Final status — refund runs on the Appstore
     * server.
     */
    private void markReceiptUnavailable(final String receiptId) {
        PurchasingService.notifyFulfillment(receiptId, FulfillmentResult.UNAVAILABLE);
        dataSource.cancelSubscription(receiptId, System.currentTimeMillis());
        if (userIapData != null) {
            reloadSubscriptionStatus();
        }
    }

    /**
     * Emit {@link FulfillmentResult#EXISTING_PURCHASE} for a receipt
     * and record the cancel locally. Call this when the customer
     * already owns the entitlement under a different active receipt.
     * Final status — refund runs on the Appstore server.
     */
    private void markReceiptExistingPurchase(final String receiptId) {
        PurchasingService.notifyFulfillment(receiptId, FulfillmentResult.EXISTING_PURCHASE);
        dataSource.cancelSubscription(receiptId, System.currentTimeMillis());
        if (userIapData != null) {
            reloadSubscriptionStatus();
        }
    }

    /**
     * Emit {@link FulfillmentResult#NOT_ELIGIBLE} for a receipt and
     * record the cancel. Call this from any partner code that decides
     * a receipt should be rejected. The actual refund runs on the Appstore server;
     * this method does not need to wait for it.
     */
    private void markReceiptNotEligible(final String receiptId) {
        PurchasingService.notifyFulfillment(receiptId, FulfillmentResult.NOT_ELIGIBLE);
        dataSource.cancelSubscription(receiptId, System.currentTimeMillis());
        if (userIapData != null) {
            reloadSubscriptionStatus();
        }
    }

}
