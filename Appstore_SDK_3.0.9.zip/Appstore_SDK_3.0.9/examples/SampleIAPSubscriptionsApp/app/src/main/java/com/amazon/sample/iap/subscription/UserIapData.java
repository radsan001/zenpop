package com.amazon.sample.iap.subscription;

import java.util.List;

/**
 * This is a simple example used in Amazon InAppPurchase Sample App, to show how
 * developer's application holding the customer's InAppPurchase data.
 * 
 * 
 */
public class UserIapData {
    private List<SubscriptionRecord> subscriptionRecords;

    private boolean subsActive;
    private boolean addonActive;
    private long subsFrom;
    private final String amazonUserId;
    private final String amazonMarketplace;

    public void setSubscriptionRecords(final List<SubscriptionRecord> subscriptionRecords) {
        this.subscriptionRecords = subscriptionRecords;
    }

    public List<SubscriptionRecord> getSubscriptionRecords() {
        return subscriptionRecords;
    }

    public String getAmazonUserId() {
        return amazonUserId;
    }

    public String getAmazonMarketplace() {
        return amazonMarketplace;
    }

    public boolean isSubsActiveCurrently() {
        return subsActive;
    }

    public boolean isAddonActiveCurrently() {
        return addonActive;
    }

    public long getCurrentSubsFrom() {
        return subsFrom;
    }

    public UserIapData(final String amazonUserId, final String amazonMarketplace) {
        this.amazonUserId = amazonUserId;
        this.amazonMarketplace = amazonMarketplace;
    }

    /**
     * Recompute base + Add-On active flags from local records. Tracked
     * separately because a customer can hold both at once.
     */
    public void reloadSubscriptionStatus() {
        this.subsActive = false;
        this.addonActive = false;
        this.subsFrom = 0;
        for (final SubscriptionRecord record : subscriptionRecords) {
            if (!record.isActiveNow()) {
                continue;
            }
            final String sku = record.getSku();
            if (MySku.MY_MAGAZINE_ADDON_PREMIUM_MONTHLY.getSku().equals(sku)) {
                this.addonActive = true;
            } else if (!this.subsActive) {
                this.subsActive = true;
                this.subsFrom = record.getFrom();
            }
        }
    }
}
